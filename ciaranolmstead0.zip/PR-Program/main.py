import os
import openai
from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv

# Load API key from .env file
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# Create FastAPI app
app = FastAPI()


# Define input format
class ReviewRequest(BaseModel):
    student_text: str


# Peer review function
def generate_peer_review(text):
    prompt = f"""
    Consider the following student writing through “x” framework

    Student Writing: {text}

    Provide a peer review response based on these ideas.
    """

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an AI that gives peer review feedback."},
            {"role": "user", "content": prompt}
        ]
    )
    return response["choices"][0]["message"]["content"]



@app.post("/peer-review")
async def peer_review(request: ReviewRequest):


# Run the API server
    if __name__ == "__main__":
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000)

@app.get("/")
def home():
    return {"message": "Welcome to the Peer Review API!"}
